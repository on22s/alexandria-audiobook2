#!/usr/bin/env bash
# Seed-3 Qwen3-8B window25 adapter at UD-Q2_K_XL on the A6000 (tnr-2): completes the seed x GPU grid.
# Same sweep script, quant and prompt as the seed-2 A6000 cell. Usage: $0 <expected md5 of the seed-3 gguf>
set -uo pipefail
R=/home/ubuntu; LOG=$R/qwen3_8b_seed3_tnr2_20260929.log; exec >> "$LOG" 2>&1
G=$R/adapters_in/qwen3-8b-rightsclean-window25-michel2v2-seed3.f16.gguf
Q=$R/models/qwen3-8b/Qwen3-8B-UD-Q2_K_XL.gguf
[ "$(md5sum < $G | cut -c1-12)" = "$1" ] || { echo "REFUSING: seed-3 md5"; exit 1; }
[ "$(sha256sum $Q | cut -c1-12)" = e1b3da4b0b69 ] || { echo "REFUSING: quant sha"; exit 1; }
h=$(cd $R/aa2_probe && python3 -c 'import hashlib,sys;sys.path.insert(0,"app");sys.path.insert(0,"app/experiments");from attribution_prompt_variants import MICHEL2_SYSTEM;print(hashlib.sha256(MICHEL2_SYSTEM.encode()).hexdigest()[:16])')
[ "$h" = a63e2124546ce050 ] || { echo "REFUSING: prompt $h"; exit 1; }
echo "$(date -Is) WAIT for a free GPU"
while nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | grep -Eq "[0-9]"; do sleep 60; done
bash $R/adapter_sweep_tail_20260928.sh "$G" qwen3-8b-window25-michel2v2-seed3 tnr-2 $Q:ud-q2kxl
echo "$(date -Is) QWEN3-8B-SEED3-TNR2 COMPLETE"
