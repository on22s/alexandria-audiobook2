#!/usr/bin/env bash
# W=1 controls for the TTS batching test: seed 43 (sampling-noise floor), then seed 42 again (determinism).
R=/home/ubuntu; cd $R; P=$R/alexandria-tts-env/bin/python
for s in 43 42; do
  echo "$(date -Is) CTL seed $s start"
  CTL_SEED=$s /home/ubuntu/alexandria-tts-env/bin/python $R/tts_ctl_20260929.py --app $R/aa2_probe/app --workers 1 --out $R/tts_ctl_w1_seed${s}_20260929.json > $R/tts_ctl_w1_seed${s}_20260929.log 2>&1
  echo "$(date -Is) CTL seed $s exit=$?"
done
echo "$(date -Is) CTL CHAIN COMPLETE"
