import hashlib,json,math,os,statistics,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root/'repo';inputs=root/'voices';result=root/'voices_run/result.json'
doc=json.loads(result.read_text());assert doc['status']=='complete' and doc['completed']==doc['requested']==80
pairs=[];labels=[]
for batch in doc['batches']:
 for clip in batch['clips']:
  human=inputs/clip['human'];assert human.is_file()
  pairs.append([str(human),clip['path']]);labels.append(batch['label'])
first=inputs/doc['batches'][0]['clips'][0]['human'];pairs.extend([[str(first),str(first)]]*2)
worker=repo/'app/experiments/_ecapa_batch.py'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',HF_HUB_OFFLINE='0')
r=subprocess.run([sys.executable,str(worker)],input=json.dumps(pairs),capture_output=True,text=True,env=env,timeout=900)
if r.returncode:raise RuntimeError(r.stderr[-2000:])
values=json.loads(r.stdout.strip().splitlines()[-1]);assert len(values)==82 and all(v is not None and math.isfinite(v) for v in values)
assert min(values[-2:])>.999
summary={}
for label in sorted(set(labels)):
 scores=[v for tag,v in zip(labels,values) if tag==label];assert len(scores)==20
 summary[label]={'n':20,'median_ecapa':statistics.median(scores),'minimum_ecapa':min(scores),'identity_threshold':.45,'passes_identity':statistics.median(scores)>=.45}
out={'status':'complete','render_result_sha256':hashlib.sha256(result.read_bytes()).hexdigest(),'scorer_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'summary':summary,'scores':list(zip(labels,values[:80])),'self_controls':values[-2:],'note':'Independent rerender of existing weights on the same20 unseen recordings; not20 new independent voices, and not a listening assessment. No automatic promotion.'}
(root/'voices_run/identity_scores.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(summary,indent=2))
