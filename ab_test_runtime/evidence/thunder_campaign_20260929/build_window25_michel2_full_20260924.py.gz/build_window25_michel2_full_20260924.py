#!/usr/bin/env python3
"""Build clean-rights michel2_full training windows that render through the
HARNESS's own prompt code, not a copy of it.

The 2026-09-23 builder wrote its own 234-character system prompt and left
narration unmarked, so its completions named only the spoken lines. The shipped
michel2_full sends a 2,071-character system prompt, marks narration entries
`[n] text`, and expects one object per marked entry with "NARRATOR" for the
narration. An adapter trained on the former and served the latter is a transfer
test, which is how the A3B adapter lost 20 points.

MICHEL2_SYSTEM, MICHEL2_INSTRUCTION and surround_passage are IMPORTED from
attribution_prompt_variants so the training prompt cannot drift from the served
one again."""
import ast
import csv
import hashlib
import json
from pathlib import Path

from attribution_prompt_variants import (MICHEL2_INSTRUCTION, MICHEL2_SYSTEM,
                                         surround_passage)

PDNC = Path("/home/ubuntu/pdnc")
SELECTED = Path("/home/ubuntu/rightsclean_data_20260914/alexandria-training-20260823/data")
OUT = Path("/home/ubuntu/window25_michel2_full_20260924")
WINDOW = 25
SURROUND = 2000
MAX_NARRATION = 1200
EVAL_BOOKS = {
    "Emma", "MansfieldPark", "NorthangerAbbey", "Persuasion",
    "PrideAndPrejudice", "SenseAndSensibility", "TheAwakening",
    "TheSignOfTheFour", "TheSunAlsoRises",
}
SPECIAL = {"UNKNOWN", "UNKNOWABLE", "UNNAMED", "NOT_DIALOGUE"}

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def chunks(text):
    text = text.strip()
    if not text:
        return []
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    out = []
    for p in paragraphs or [text]:
        while len(p) > MAX_NARRATION:
            cut = p.rfind(" ", 0, MAX_NARRATION)
            if cut < MAX_NARRATION // 2:
                cut = MAX_NARRATION
            out.append(p[:cut].strip())
            p = p[cut:].strip()
        if p:
            out.append(p)
    return out

def character_data(folder):
    labels, roster = {}, []
    with (folder / "character_info.csv").open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            canonical = (row.get("Main Name") or "").strip().upper()
            if not canonical:
                continue
            try:
                aliases = ast.literal_eval(row.get("Aliases") or "[]")
            except (SyntaxError, ValueError):
                aliases = []
            forms = [canonical] + [str(x).strip().upper() for x in aliases]
            labels.update({form: canonical for form in forms if form})
            roster.append((canonical, tuple(sorted({x for x in forms if x != canonical}))))
    return labels, sorted(set(roster))

def selected_indexes():
    selected = {}
    for path in sorted(SELECTED.glob("train__pdnc_*.jsonl")):
        for raw in path.open(encoding="utf-8"):
            row = json.loads(raw)
            book = row["book"].removeprefix("pdnc_")
            selected.setdefault(book, set()).add(int(row["segment_index"]))
    # The older training selection predates the current nine-book evaluation set.
    # Remove any now-evaluated book before a window is built; this is a data split,
    # not a post-hoc score filter.
    for book in sorted(set(selected) & EVAL_BOOKS):
        del selected[book]
    return selected

def source_entries(book, wanted):
    folder = PDNC / "data" / book
    labels, roster = character_data(folder)
    source = (folder / "novel_text.txt").read_text(encoding="utf-8")
    quotes = []
    with (folder / "quotation_info.csv").open(encoding="utf-8-sig", newline="") as handle:
        for ordinal, row in enumerate(csv.DictReader(handle)):
            if ordinal not in wanted:
                continue
            speaker = labels.get((row.get("speaker") or "").strip().upper())
            if not speaker or speaker in SPECIAL:
                continue
            try:
                spans = ast.literal_eval(row.get("quoteByteSpans") or "[]")
                start = min(int(x[0]) for x in spans)
                end = max(int(x[1]) for x in spans)
            except (SyntaxError, ValueError, TypeError, IndexError):
                continue
            quote = (row.get("quoteText") or "").strip()
            if quote and 0 <= start < end <= len(source):
                quotes.append((start, end, ordinal, quote, speaker))
    # Only selected quotes are insufficient to form a real passage. Re-read all
    # quotes for the actual segmentation and labels.
    all_quotes = []
    with (folder / "quotation_info.csv").open(encoding="utf-8-sig", newline="") as handle:
        for ordinal, row in enumerate(csv.DictReader(handle)):
            speaker = labels.get((row.get("speaker") or "").strip().upper())
            if not speaker or speaker in SPECIAL:
                continue
            try:
                spans = ast.literal_eval(row.get("quoteByteSpans") or "[]")
                start = min(int(x[0]) for x in spans)
                end = max(int(x[1]) for x in spans)
            except (SyntaxError, ValueError, TypeError, IndexError):
                continue
            quote = (row.get("quoteText") or "").strip()
            if quote and 0 <= start < end <= len(source):
                all_quotes.append((start, end, ordinal, quote, speaker))
    entries, positions, cursor = [], {}, 0
    for start, end, ordinal, quote, speaker in sorted(all_quotes):
        if start < cursor:  # nested/overlapping source quotation: don't invent a span.
            continue
        entries.extend({"type": "NARRATOR", "text": text} for text in chunks(source[cursor:start]))
        positions[ordinal] = len(entries)
        entries.append({"type": "SPOKEN", "text": quote, "speaker": speaker})
        cursor = end
    entries.extend({"type": "NARRATOR", "text": text} for text in chunks(source[cursor:]))
    return entries, positions, roster, source

def roster_line(roster):
    return ", ".join(
        canonical + (f" (also: {', '.join(aliases)})" if aliases else "")
        for canonical, aliases in roster
    ) or "(none yet)"

def make_example(book, entries, start, roster):
    window = entries[start:start + WINDOW]
    if not any(entry["type"] == "SPOKEN" for entry in window):
        return None
    before = " ".join(e["text"] for e in entries[:start][::-1])[:SURROUND][::-1]
    after = " ".join(e["text"] for e in entries[start + len(window):])[:SURROUND]

    # EVERY entry in the window is marked and must be answered, exactly as the
    # served michel2_full does it: spoken as |n|"..."|n|, narration as [n].
    marked, targets = [], []
    for n, entry in enumerate(window):
        marked.append({"n": n, "type": entry["type"], "text": entry["text"]})
        targets.append({"n": n,
                        "speaker": entry["speaker"] if entry["type"] == "SPOKEN"
                        else "NARRATOR"})

    passage = surround_passage({"entries": marked, "before": before, "after": after})
    user = f"ROSTER: {roster_line(roster)}\n\n{passage}\n\n{MICHEL2_INSTRUCTION}"
    return {"book": "pdnc_" + book, "system": MICHEL2_SYSTEM, "user": user,
            "completion": json.dumps(targets, ensure_ascii=False)}

def main():
    wanted = selected_indexes()
    OUT.mkdir(parents=True, exist_ok=True)
    examples, coverage, source_hashes = [], {}, {}
    for book, indexes in sorted(wanted.items()):
        entries, positions, roster, source = source_entries(book, indexes)
        starts = sorted({(positions[i] // WINDOW) * WINDOW for i in indexes if i in positions})
        examples.extend(example for start in starts if (example := make_example(book, entries, start, roster)))
        coverage[book] = {"selected_quotes": len(indexes), "covered_quotes": sum(i in positions for i in indexes),
                          "windows": len(starts), "entries": len(entries)}
        folder = PDNC / "data" / book
        source_hashes[book] = {name: sha256(folder / name) for name in
                               ("novel_text.txt", "quotation_info.csv", "character_info.csv")}
    if not examples:
        raise RuntimeError("no training examples built")
    data = OUT / "train_windows.jsonl"
    with data.open("w", encoding="utf-8") as handle:
        for example in examples:
            handle.write(json.dumps(example, ensure_ascii=False) + "\n")
    lengths = sorted(len(x["user"]) for x in examples)
    manifest = {
        "schema_version": 1,
        "prompt_contract": "michel2_full_window25_surround2000",
        "window_entries": WINDOW, "surround_chars": SURROUND,
        "narration_split_max_chars": MAX_NARRATION,
        "source": "PDNC clean-rights source text + quotation_info.csv + character_info.csv",
        "evaluation_books_excluded": sorted(EVAL_BOOKS),
        "examples": len(examples),
        "prompt_chars": {"min": lengths[0], "median": lengths[len(lengths)//2], "max": lengths[-1]},
        "coverage": coverage, "source_sha256": source_hashes,
        "data_sha256": sha256(data),
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))

if __name__ == "__main__":
    main()
