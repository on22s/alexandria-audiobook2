import json,sys
from pathlib import Path
from huggingface_hub import snapshot_download
models=['Qwen/Qwen3-TTS-12Hz-1.7B-Base']
if sys.argv[1]=='chapter':models.append('Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign')
records=[]
for name in models:
 path=snapshot_download(name)
 records.append({'model':name,'snapshot':path,'revision':Path(path).name})
print(json.dumps(records,indent=2))
