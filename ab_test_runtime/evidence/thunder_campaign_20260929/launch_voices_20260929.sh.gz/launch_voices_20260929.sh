#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/ubuntu/thunder_campaign_20260929
REPO=$ROOT/repo
cd "$REPO"
export GPU_LOCK=/home/ubuntu/aa2_probe/ab_test_runtime/logs/alexandria_gpu.lock
export GPU_PAUSE_FLAG=/home/ubuntu/aa2_probe/ab_test_runtime/logs/gpu_paused
export GPU_NOTIFY=0
export HF_HUB_OFFLINE=1
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:/usr/local/cuda/targets/x86_64-linux/lib
export PYTHONPATH="$REPO/app"
bash gpu_job.sh thunder_voices_20260929 bash app/experiments/wait_thunder_gpu.sh /home/ubuntu/alexandria-tts-env/bin/python -u app/experiments/thunder_audio_campaign.py --inputs "$ROOT/voices" --out "$ROOT/voices_run/result.json"

CUDA_VISIBLE_DEVICES="" OMP_NUM_THREADS=4 /home/ubuntu/alexandria-tts-env/bin/python -u "$ROOT/score_voices_20260929.py"
