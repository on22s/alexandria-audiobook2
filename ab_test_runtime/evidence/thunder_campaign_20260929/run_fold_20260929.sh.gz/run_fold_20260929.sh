#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/ubuntu/thunder_campaign_20260929
REPO=$ROOT/repo
DATA=$ROOT/fold_swap
OUT=$ROOT/fold_adapter
PY=/home/ubuntu/muse-train-env/bin/python
MODEL=/home/ubuntu/qwen3_8b_hf_download_20260923
mkdir -p "$OUT"
cd "$REPO"
echo "START fold-swap training"
PYTHONPATH="$REPO/app" "$PY" -u app/experiments/train_thunder_fold_swap.py --data "$DATA/train_windows.jsonl" --model "$MODEL" --chat-template "$DATA/chat_template.jinja" --out "$OUT" --epochs 1 --lr 2e-4 --lora_r 16 --lora_alpha 16 --batch_size 1 --grad_accum 8 --max_len 8192 --save_steps 50 --seed 20260924 --data-seed 20260924
G=$OUT/qwen3-8b-foldswap.f16.gguf
"$PY" /home/ubuntu/llama.cpp/convert_lora_to_gguf.py "$OUT" --base "$MODEL" --outfile "$G" --outtype f16
SERVER_PID=
cleanup() { if [ -n "$SERVER_PID" ]; then kill -TERM "$SERVER_PID" 2>/dev/null || true; wait "$SERVER_PID" 2>/dev/null || true; fi; }
trap cleanup EXIT
/home/ubuntu/llama.cpp/build-a100-20260916/bin/llama-server -m /home/ubuntu/models/qwen3-8b/Qwen3-8B-UD-Q2_K_XL.gguf --lora "$G" --alias qwen3-8b-foldswap --host 127.0.0.1 --port 8177 -ngl 99 -c 32768 --parallel 1 --flash-attn on --reasoning on --reasoning-budget 1024 > "$ROOT/fold_server.log" 2>&1 &
SERVER_PID=$!
healthy=
for attempt in $(seq 1 300); do
 if curl -fsS http://127.0.0.1:8177/health >/dev/null 2>&1; then healthy=1; break; fi
 kill -0 "$SERVER_PID" 2>/dev/null || { echo 'Server died'; exit 2; }
 sleep 2
done
[ "$healthy" = 1 ] || { echo 'Server never became healthy'; exit 2; }
python3 -u app/experiments/run_thunder_fold_eval.py --fixtures-root "$DATA" --books pdnc_ahandfulofdust pdnc_apassagetoindia pdnc_aroomwithaview pdnc_alicesadventuresinwonderland pdnc_anneofgreengables pdnc_daisymiller pdnc_hardtimes pdnc_howardsend pdnc_nightandday pdnc_olivertwist pdnc_theageofinnocence pdnc_thegambler pdnc_theinvisibleman pdnc_themanwhowasthursday pdnc_themysteriousaffairatstyles pdnc_thepictureofdoriangray pdnc_thesportofthegods pdnc_whereangelsfeartotread pdnc_winniethepooh --model qwen3-8b-foldswap --base_url http://127.0.0.1:8177/v1 --batch-size 25 --max-tokens 4096 --reasoning-effort low --structured-output auto --prompt-variant michel2_full --window-limit 40 --input-dir "$DATA/inputs" --checkpoint-dir "$DATA/checkpoints" --tag qwen3-8b-foldswap9-eval19-tnr1-20260929
printf '%s\n' 'DONE fold-swap train and paired evaluation'
